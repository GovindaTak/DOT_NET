﻿using Microsoft.Data.SqlClient;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Employees_Management_MVC_application.Models
{
    public class Employee
    {
        public int? EmpId { get; set; }
        [Required(ErrorMessage = "please give name !!")]
        public string Name { get; set; }
        [Required(ErrorMessage = "please enter city !!")]
        public string City { get; set; }
        [Required(ErrorMessage = "please Enter Address!!")]
        public string Address { get; set; }

        public override string ToString()
        {
            return EmpId + " ," + Name + " ," + City + " ," + Address;
        }
    }
    public  class EmployeeUtill : IEmployeeUtill,IDisposable
    {
        private static SqlConnection cn;
         static EmployeeUtill()
        { cn=connection.GetConnection(); }

        public void Add(Employee employee)
        {

            SqlTransaction t = cn.BeginTransaction();
                try
                 {
                SqlCommand cmd = new SqlCommand();
                    cmd.Connection = cn;
                    cmd.Transaction = t;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "insert into Employees values(@EmpId, @Name, @City,@Address)";
                cmd.Parameters.AddWithValue("Name",employee.Name);
                cmd.Parameters.AddWithValue("City", employee.City);
                cmd.Parameters.AddWithValue("Address", employee.Address);
                cmd.Parameters.AddWithValue("EmpId", employee.EmpId);

                cmd.ExecuteNonQuery();
                t.Commit();
                  } catch (Exception)
                 {
                t.Rollback();
                throw;
                 }
        }

        public string Delete(int id)
        {
            SqlTransaction t = cn.BeginTransaction();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.Transaction = t;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "DeleteEmployee";
                cmd.Parameters.AddWithValue("EmpId",id);
                cmd.ExecuteNonQuery();
                t.Commit();
              
            }
            catch (Exception)
            {
                t.Rollback();
                throw;
            }
            return "Deleted !!";
        }

        public void Dispose()
        {
            cn.Close();
        }

        public List<Employee> GetAllEmployees()
        {
                List<Employee> list = new List<Employee>();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
              
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "GetAllEmployees";
              using(SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Employee employee = new Employee();
                        employee.EmpId = reader.GetInt32("empid");//db col name 
                        employee.Address=reader.GetString("address");
                        employee.Name=reader.GetString("name");
                        employee.City = reader.GetString("city");
                        list.Add(employee);
                    }
                }
              }
            catch (Exception)
            {
               
                throw;
            }
            return list;
        }

        public Employee GetById(int id)
        {
            Employee e = null;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "GetById";
                cmd.Parameters.AddWithValue("EmpId", id);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Employee employee = new Employee();
                        employee.EmpId = reader.GetInt32("empid");//db col name 
                        employee.Address = reader.GetString("address");
                        employee.Name = reader.GetString("name");
                        employee.City = reader.GetString("city");
                        e = employee;
                    }
                }

            }
            catch (Exception)
            {

                throw;
            }
            return e;
        }

        public string UpdateEmployee(Employee employee)
        {
            SqlTransaction t = cn.BeginTransaction();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.Transaction = t;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "UpdateEmployee";
                cmd.Parameters.AddWithValue("EmpId", employee.EmpId);
                cmd.Parameters.AddWithValue("Name", employee.Name);
                cmd.Parameters.AddWithValue("City", employee.City);
                cmd.Parameters.AddWithValue("Address", employee.Address);

                cmd.ExecuteNonQuery();
                t.Commit();
            }
            catch (Exception)
            {
                t.Rollback();
                throw;
            }
            return "Updated!!";
        }
    }
}
