﻿using System;
using System.Collections.Generic;

namespace EmployeesMVC.Models;

public partial class TblEmployee
{
    public int EmployeeId { get; set; }

    public string EmployeeName { get; set; } = null!;

    public string? EmployeeCity { get; set; }
    
    public DateTime? EmployeeDob { get; set; }

    public string? EmployeeGender { get; set; }

    public decimal? EmployeeSalary { get; set; }

    public override string ToString()
    {
        return " id : " + EmployeeId + " name : " + EmployeeName + " city:" + EmployeeCity + " Gender : " + EmployeeGender + " Dob :" + EmployeeDob + " Salary : " + EmployeeSalary;
    }
}
