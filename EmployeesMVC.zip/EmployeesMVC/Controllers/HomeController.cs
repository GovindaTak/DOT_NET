﻿using EmployeesMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace EmployeesMVC.Controllers
{
    public class HomeController : Controller
    {
        private LabExamEmployeeDatabaseContext MyDataBase;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, LabExamEmployeeDatabaseContext DbContext)
        {
            _logger = logger;
            MyDataBase = DbContext;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> ViewEmployees()
        {
            var list= await MyDataBase.TblEmployees.ToListAsync<TblEmployee>();
            if(list.Count > 0)
            {
                return View(list);
            }
            else
            {
                ViewBag.Msg = "NO Employee Register Yet !!!";
                return View();
            }
           
        }

        [HttpGet]
        public IActionResult AddEmployee()
        {

            return View();
        }
        [HttpPost]//url : Home/AddEmployee in post way
        public async Task<IActionResult> AddEmployee(TblEmployee NewEmployee) 
        { 
            
            var item= MyDataBase.TblEmployees.Add(NewEmployee);
                   var item2= await MyDataBase.SaveChangesAsync();
             Console.WriteLine(NewEmployee);
            Console.WriteLine(item);
            Console.WriteLine(item2);
            return View("ShowEmployee",NewEmployee);
           }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}