﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace lab_Exam_Practice_WEBAPI_1.Models;

public partial class TblEmployee
{
    public int EmployeeId { get; set; }
    
    public string EmployeeName { get; set; } = null!;
    
    public string? EmployeeCity { get; set; }
    
    public DateTime? EmployeeDob { get; set; }

    public string? EmployeeGender { get; set; }
    [Range(10000, 100000,ErrorMessage ="Salary not in range !!!")]
    public decimal? EmployeeSalary { get; set; }
}
