﻿using Employees_Management_MVC_application.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Employees_Management_MVC_application.Controllers
{
    public class EmployeesController : Controller
        {
        private static EmployeeUtill Eutill;

       static EmployeesController()
        {
            Eutill = new EmployeeUtill();
        }
        // GET: Employees
        public ActionResult Index()
        {
            List<Employee>list=Eutill.GetAllEmployees();
            if(list.Count == 0)
            {
                ViewBag.MSG = "NO Employee Register Yet !!";
             
            }
            return View(list);
        }

        // GET: EmployeesController/Details/5
        //public ActionResult Details(int id)
        //{
        //    return View();
        //}

        // GET: EmployeesController/Create
        public ActionResult Create()
        {

            return View();
        }

        // POST: EmployeesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee e)
        {
            try
            {
                Eutill.Add(e);
                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                ViewBag.MSG = ex.Message;
                return View();
            }
        }

        // GET: Employees/Edit/5
        public ActionResult Edit(int id)
        {   Employee e=Eutill.GetById(id);
            if (e != null)
            {
                return View(e);
            }
            else
            return RedirectToAction("Index");
        }

        // POST: EmployeesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Employee e)
        {
            try
            {
                Eutill.UpdateEmployee(e);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeesController/Delete/5
        public ActionResult Delete(int id)
        {
            Employee e = Eutill.GetById(id);
            if (e != null)
            {
                return View(e);
            }
            else
                return RedirectToAction("Index");
        }

        // POST: EmployeesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                Eutill.Delete(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
