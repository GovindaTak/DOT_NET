﻿using Microsoft.Data.SqlClient;

namespace Employees_Management_MVC_application.Models
{
    public class connection
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=EmployeesManagementMVCApp;Integrated Security=True";
            cn.Open();
            return cn;
        }
    }
}
