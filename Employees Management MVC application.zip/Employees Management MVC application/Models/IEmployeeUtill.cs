﻿namespace Employees_Management_MVC_application.Models
{
    public interface IEmployeeUtill
    {
        void Add(Employee employee);
        List<Employee> GetAllEmployees();
        string Delete(int id);
        string UpdateEmployee(Employee employee);

        Employee GetById(int id);
    }
}
